﻿using DCAM.Application.Interfaces;
using DCAM.Application.Services;
using DCAM.Domain.CommandHandlers;
using DCAM.Domain.Commands;
using DCAM.Domain.Core.Bus;
using DCAM.Domain.Interfaces;
using DCAM.Infra.Bus;
using DCAM.Infra.Data.Context;
using DCAM.Infra.Data.Repository;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Graph;
using System;
using System.Collections.Generic;
using System.Text;

namespace DCAM.Infra.IoC
{
    public class DependencyContainer
    {
        public static void RegisterServices(IServiceCollection services)
        {
            //Domain InMemoryBus MediatR
            // services.AddScoped<IMediatorHandler, InMemoryBus>();

            //Domain Handlers
            // services.AddScoped<IRequestHandler<CreateCourseCommand, bool>, CourseCommandHandler>();

            //Application Layer 
            // services.AddScoped<ICourseService, CourseService>();
            services.AddScoped<IAuthenticationService, AuthenticationService>();
            services.AddScoped<IAuthorizationService, AuthorizationService>();
            services.AddScoped<IGraphService, GraphService>();

            //Infra.Data Layer
            //services.AddScoped<ICourseRepository, CourseRepository>();
            //services.AddScoped<UniversityDBContext>();
        }
    }
}
