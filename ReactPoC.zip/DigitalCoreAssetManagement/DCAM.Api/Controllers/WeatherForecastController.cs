using AutoMapper;
using Chevron.Identity;
using Chevron.Identity.AspNet.Client;
using DCAM.Application.Interfaces;
using DCAM.Application.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace DCAM.Api.Controllers
{
 
    [ApiController]
    [Route("api/[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<WeatherForecastController> _logger;
        private readonly ICvxHttpClient _client;
        private readonly IAzureADOptions _options;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, ICvxClaimsPrincipal _, ICvxHttpClient client, IOptionsMonitor<AzureADOptions> optionsAccessor)
        {
            _logger = logger;
            _options = optionsAccessor.CurrentValue;
            _client = client;
        }
        //[Authorize]
        [HttpGet]
        [Route("GetWeatherForecast")]
        public IEnumerable<WeatherForecast> GetWeatherForecast()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }

        //[Authorize]
        [HttpGet]
        [Route("Getabc")]
        public async Task<string> Getabc()
        {
            Credentials creds = CreateCredentials.Oauth2Delegated(_options, "https://tcodcam-test.azure.chevron.com/user_impersonation");

            string result = await _client.AddCredentials(creds).GetAsStringAsync("https://tcodcam-test.azure.chevron.com/user_impersonation");

            return result;
        }
    }
}