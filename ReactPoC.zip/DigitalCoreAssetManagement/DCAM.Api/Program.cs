using Chevron.Identity;
using Chevron.Identity.AspNet.Client;
using Chevron.Net.Http;
using DCAM.Api.Middleware.AntiXssMiddleware;
using DCAM.Infra.Data.Context;
using DCAM.Infra.IoC;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.CookiePolicy;
using Microsoft.AspNetCore.SpaServices.AngularCli;
using Microsoft.AspNetCore.SpaServices.ReactDevelopmentServer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Net.Http.Headers;
using Microsoft.OpenApi.Models;
using System.Configuration;
using System.Reflection;
//using Microsoft.AspNetCore.SpaServices.Webpack;


//var builder = WebApplication.CreateBuilder(args);

//// Add services to the container.

//builder.Services.AddControllers();
//// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
//builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();
//builder.Services.AddCal(builder.Configuration, true);
//builder.Services.AddSingleton<ICvxHttpClient, CvxHttpClient>();

////builder.Services.AddDbContext<UniversityDBContext>(options =>
////{
////    options.UseSqlServer(builder.Configuration.GetConnectionString("UniversityDBConnection"));
////});
//builder.Services.AddMediatR(Assembly.GetExecutingAssembly());
//DependencyContainer.RegisterServices(builder.Services);
//var app = builder.Build();

//// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
//    app.UseAuthentication();
//    app.UseCalMiddleware();
//    app.UseSwagger();
//    app.UseSwaggerUI();
//}

//// app.UseAuthorization();

//app.MapControllers();

//app.Run();

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "DCAM.API", Version = "v1" });

    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
    {
        Description = "JWT Authorization header using the Bearer scheme. Example: \"Bearer {token}\"",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        Array.Empty<string>()
                    }
                });
});
builder.Services.AddCal(builder.Configuration, true);
builder.Services.AddSingleton<ICvxHttpClient, CvxHttpClient>();
builder.Services.AddCors(options =>
{
    options.AddPolicy(name: "CorsPolicy",
                       p => p.AllowAnyMethod().AllowAnyHeader().WithOrigins("http://localhost:3000"));
                                                   
});

DependencyContainer.RegisterServices(builder.Services);

var app = builder.Build();





//CAL
app.UseAuthentication();
app.UseCalMiddleware();

app.Use(async (context, next) =>
{
    context.Response.Headers.Add("X-Frame-Options", "SAMEORIGIN");
    context.Response.Headers.Add("X-Xss-Protection", "1; mode=block");
    context.Response.Headers.Add("Referrer-Policy", "same-origin");
    await next();
});
// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
//    app.UseSwagger();
//    app.UseSwaggerUI();
//}
if (app.Environment.IsDevelopment() || app.Environment.IsStaging())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "DCAM.API v1");
    });
}
else
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}
app.UseHttpsRedirection();
app.UseAntiXssMiddleware();
app.UseStaticFiles();
app.UseCookiePolicy(new CookiePolicyOptions
{
    HttpOnly = HttpOnlyPolicy.Always,
    MinimumSameSitePolicy = Microsoft.AspNetCore.Http.SameSiteMode.Strict
});

app.UseRouting();
app.UseCors("CorsPolicy");
app.UseAuthorization();

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller}/{action=Index}/{id?}");
});


//app.UseSpa(spa =>
//{
//    // To learn more about options for serving an Angular SPA from ASP.NET Core,
//    // see https://go.microsoft.com/fwlink/?linkid=864501

//    spa.Options.SourcePath = "_/Presentation/dcam.client";

//    spa.Options.DefaultPageStaticFileOptions = new StaticFileOptions
//    {
//        OnPrepareResponse = ctx =>
//        {
//            var headers = ctx.Context.Response.GetTypedHeaders();
//            headers.CacheControl = new CacheControlHeaderValue
//            {
//                NoCache = true,
//                NoStore = true,
//                MustRevalidate = true,
//                MaxAge = TimeSpan.Zero
//            };
//        }
//    };


//    if (app.Environment.IsDevelopment())
//    {
//        spa.UseReactDevelopmentServer(npmScript: "start");
//    }
//});
string parent = Path.Combine(Directory.GetParent(Directory.GetCurrentDirectory()).FullName);
var path = Path.Combine(Directory.GetCurrentDirectory(), "DCAM.Client\\dcam.client");



//app.Map("/Presentation", app1 =>
//{
//app.UseSpa(spa =>
//    {
//        // To learn more about options for serving an Angular SPA from ASP.NET Core,
//        // see https://go.microsoft.com/fwlink/?linkid=864501

//        spa.Options.SourcePath = path;
//        spa.Options.DefaultPageStaticFileOptions = new StaticFileOptions
//        {
//            OnPrepareResponse = ctx =>
//            {
//                var headers = ctx.Context.Response.GetTypedHeaders();
//                headers.CacheControl = new CacheControlHeaderValue
//                {
//                    NoCache = true,
//                    NoStore = true,
//                    MustRevalidate = true,
//                    MaxAge = TimeSpan.Zero
//                };
//            }
//        };


//        if (app.Environment.IsDevelopment())
//        {
//            spa.UseReactDevelopmentServer(npmScript: "start");
//        }

//    });
//});
app.Run();








