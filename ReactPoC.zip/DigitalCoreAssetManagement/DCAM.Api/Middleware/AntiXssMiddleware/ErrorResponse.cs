﻿namespace DCAM.Api.Middleware.AntiXssMiddleware
{
	public class ErrorResponse
	{
		public int ErrorCode { get; set; }
		public string Description { get; set; }
	}
}
