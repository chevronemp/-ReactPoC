﻿namespace DCAM.Application.ViewModels
{
    public class PermissionsResult
    {
        public bool IsAllowToViewDashboardPage { get; set; }
    }
}
