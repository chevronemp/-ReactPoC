﻿using Chevron.Identity;
using Chevron.Identity.AspNet.Client;
using DCAM.Application.Interfaces;

namespace DCAM.Application.Services
{
	public class AuthenticationService : IAuthenticationService
	{
		public AuthenticationService(ICvxClaimsPrincipal _)
		{
		}

		public CvxClaimsPrincipal CurrentPrincipal
		{
			get
			{
				return CvxClaimsPrincipal.Current;
			}
		}
	}
}
