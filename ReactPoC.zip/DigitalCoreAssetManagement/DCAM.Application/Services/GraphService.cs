﻿using Chevron.Identity;
using Chevron.Identity.AspNet.Client;
using DCAM.Application.Interfaces;
using Microsoft.Extensions.Options;
using Microsoft.Graph;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace DCAM.Application.Services
{
    public class GraphService : IGraphService
    {
        private readonly ICvxHttpClient _cvxHttpClient;
        private readonly IAzureADOptions _azureADOptions;

        public GraphService(ICvxHttpClient cvxHttpClient,
            IOptionsMonitor<AzureADOptions> options)
        {
            _cvxHttpClient = cvxHttpClient;
            _azureADOptions = options.CurrentValue;
        }

        public async Task<List<Group>> GetCurrentUserMembershipAsync()
        {
            var groups = new List<Group>();
            var pages = await _cvxHttpClient.AddCredentials(GetCredentials())
                .GetAsync<ODataList<Group>>($"https://graph.microsoft.com/v1.0/me/memberOf");

            groups.AddRange(pages.Value);

            while (pages.NextLink != null)
            {
                pages = await _cvxHttpClient.AddCredentials(GetCredentials())
                .GetAsync<ODataList<Group>>(pages.NextLink);
                groups.AddRange(pages.Value);
            }

            return groups;
        }

        private Credentials GetCredentials()
        {
            var credentials = new Credentials()
            {
                User = CvxClaimsPrincipal.Current,
                Options = _azureADOptions,
                Scopes = _azureADOptions.GraphScopes
            };

            return credentials;
        }
    }
}


