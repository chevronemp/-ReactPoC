﻿using Chevron.Identity;
using Chevron.Identity.AspNet.Client;

namespace DCAM.Application.Services
{
    public static class CreateCredentials
    {
        public static Credentials BasicAuth(string username, string password)
        {
            Credentials creds = new Credentials()
            {
                Username = username,
                Password = password
            };

            return creds;
        }

        public static Credentials Oauth2Delegated(IAzureADOptions options, string scopes)
        {
            Credentials creds = new Credentials()
            {
                User = CvxClaimsPrincipal.Current,
                Options = options,
                Scopes = scopes
            };

            return creds;
        }

        public static Credentials Oauth2Application(IAzureADOptions options, string scopes)
        {
            Credentials creds = new Credentials()
            {
                Options = options,
                Scopes = scopes
            };

            return creds;
        }
    }
}
