﻿using DCAM.Application.Interfaces;
using DCAM.Application.ViewModels;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System;
using System.Linq;
using System.Threading.Tasks;


namespace DCAM.Application.Services
{
    public class AuthorizationService : IAuthorizationService
    {
        private readonly IConfiguration _configuration;
        private readonly IGraphService _graphService;
        private readonly IMemoryCache _cache;
        private readonly IAuthenticationService _authenticationService;

        public AuthorizationService(
            IAuthenticationService authenticationService,
            IMemoryCache cache,
            IConfiguration configuration,
            IGraphService graphService)
        {
            _authenticationService = authenticationService;
            _cache = cache;
            _configuration = configuration;
            _graphService = graphService;
        }

        public async Task<PermissionsResult> GetUserPermissionsAsync()
        {
            var currentUserName = _authenticationService.CurrentPrincipal.Username;
            var cacheKey = $"Permissions_{currentUserName}";

            if (!_cache.TryGetValue(cacheKey, out PermissionsResult permissionsResult))
            {
                permissionsResult = new PermissionsResult();
                var currentUserMembership = await _graphService.GetCurrentUserMembershipAsync();
                var currentUserGroupNames = currentUserMembership?.Select(x => x.DisplayName.ToUpper())?.ToList();
                
                if (currentUserGroupNames != null)
                {
                    if (_configuration.GetValue<string>("PermissionGroups:FullAccess")
                        .ToUpper()
                        .Split(',')
                        .Any(currentUserGroupNames.Contains))
                    {
                        permissionsResult.IsAllowToViewDashboardPage = true;
                    }
                    else if (_configuration.GetValue<string>("PermissionGroups:Read-only")
                        .ToUpper()
                        .Split(',')
                        .Any(currentUserGroupNames.Contains))
                    {
                        permissionsResult.IsAllowToViewDashboardPage = false;
                    }
                    else if (_configuration.GetValue<string>("PermissionGroups:PE-group")
                        .ToUpper()
                        .Split(',')
                        .Any(currentUserGroupNames.Contains))
                    {
                        permissionsResult.IsAllowToViewDashboardPage = false;
                        
                    }
                    else if (_configuration.GetValue<string>("PermissionGroups:RMG-group")
                        .ToUpper()
                        .Split(',')
                        .Any(currentUserGroupNames.Contains))
                    {
                        permissionsResult.IsAllowToViewDashboardPage = false;
                        
                    }
                    else if (_configuration.GetValue<string>("PermissionGroups:Management-group")
                        .ToUpper()
                        .Split(',')
                        .Any(currentUserGroupNames.Contains))
                    {
                        permissionsResult.IsAllowToViewDashboardPage = true;
                       
                    }

                    _cache.Set(cacheKey, permissionsResult, TimeSpan.FromMinutes(30));
                }
            }

            return permissionsResult;
        }

        public async Task<bool> IsAllowToViewDashboardPageAsync()
        {
            var permissionResult = await GetUserPermissionsAsync();

            return permissionResult.IsAllowToViewDashboardPage;
        }
    }
}
