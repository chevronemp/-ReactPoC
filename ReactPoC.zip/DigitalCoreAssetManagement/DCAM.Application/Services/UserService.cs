﻿using Chevron.Identity;
using Chevron.Identity.AspNet.Client;
using Microsoft.Extensions.Options;
using Microsoft.Graph;
using System;
using System.Net;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Chevron.MID.Interfaces;
using Chevron.MID;
using DCAM.Application.ViewModels;

namespace DCAM.Application.Services
{
    public class UserService
    {
        private readonly IAzureADOptions _options;
        private readonly ITokenManagerProvider _tokenManager;
        private readonly ICvxHttpClient _client;

        public UserService
        (
            ICvxClaimsPrincipal _, 
            IOptionsMonitor<AzureADOptions> optionsAccessor, 
            ITokenManagerProvider tokenManager, 
            ICvxHttpClient client
        )
        {
            _options = optionsAccessor.CurrentValue;
            _tokenManager = tokenManager;
            _client = client;
        }

        public async Task<UserProfile> GetProfile()
        {
            ICmidConnector connector = await GetCmidConnector();

            UserProfile userProfile = new UserProfile();

            if ( CvxClaimsPrincipal.Current.Identity.IsAuthenticated && userProfile != null)
            {
                ICmidUser graphInfo = await connector.GetDirectoryUserAsync();

                userProfile = new UserProfile()
                {
                    Name = graphInfo.DisplayName,
                    JobTitle = graphInfo.JobTitle,
                    Photo = await GetPhotoBytes(),
                    Email = graphInfo.Mail,
                    Phone = graphInfo.MobilePhone,
                    Location = graphInfo.OfficeLocation
                };
            }

            return userProfile;
        }

        private async Task<string> GetPhotoBytes()
        {
            ICmidConnector connector = await GetCmidConnector();

            byte[] photoBytes = await connector.GetDirectoryUserPhotoAsync();
            string graphPhoto = CmidConnector.ConvertPhotoBytesToDataUrl(photoBytes);

            return graphPhoto;
        }

        public async Task<ICmidConnector> GetCmidConnector()
        {
            // Create credentials object by using delegated user credentials.
            Credentials creds = new Credentials()
            {
                User = CvxClaimsPrincipal.Current,
                Options = _options,
                Scopes = _options.GraphScopes
            };

            // Retrieve access token from the token manager provided by CAL.
            var token = await _tokenManager.GetOboAccessTokenAsync(creds);

            // Create a GraphDirectoryConnector object by passing in the access token
            ICmidConnector connector = new CmidConnector(token);

            return connector;
        }
    }
}
