﻿using Chevron.Identity.AspNet.Client;

namespace DCAM.Application.Interfaces
{
    public interface IAuthenticationService
	{
		CvxClaimsPrincipal CurrentPrincipal { get; }
	}
}
