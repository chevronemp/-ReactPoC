﻿using Microsoft.Graph;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DCAM.Application.Interfaces
{
    public interface IGraphService
    {
        Task<List<Group>> GetCurrentUserMembershipAsync();
    }
}
