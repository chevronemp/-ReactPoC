﻿using DCAM.Application.ViewModels;
using System.Threading.Tasks;


namespace DCAM.Application.Interfaces
{
    public interface IAuthorizationService
    {
        Task<PermissionsResult> GetUserPermissionsAsync();
        Task<bool> IsAllowToViewDashboardPageAsync();
       
    }
}
