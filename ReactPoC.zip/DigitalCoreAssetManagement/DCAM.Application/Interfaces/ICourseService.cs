﻿using DCAM.Application.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace DCAM.Application.Interfaces
{
    public interface ICourseService
    {
        CourseViewModel GetCourses();
        void Create(CourseViewModel courseViewModel);
    }
}
