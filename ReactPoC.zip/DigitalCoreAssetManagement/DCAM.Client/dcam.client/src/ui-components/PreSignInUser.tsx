import { useEffect, useState } from "react";
import { useMsal } from "@azure/msal-react";
import Button from "@material-ui/core/Button";
import MenuItem from '@material-ui/core/MenuItem';
import Menu from '@material-ui/core/Menu';
import { loginRequest } from "../authConfig";

export const PreSignInUser = () => {
    const { instance } = useMsal();

    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const open = Boolean(anchorEl);

    useEffect(() => {
        setAnchorEl(null);
        instance.loginRedirect(loginRequest);
    }, []);

    return (
        <div />
    )
};