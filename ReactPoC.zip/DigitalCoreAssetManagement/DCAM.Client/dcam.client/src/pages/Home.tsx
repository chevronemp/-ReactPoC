import { AuthenticatedTemplate, UnauthenticatedTemplate } from "@azure/msal-react";
import { TextField } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import ButtonGroup from "@material-ui/core/ButtonGroup";
import Typography from "@material-ui/core/Typography";
import axios from "axios";
import { useEffect } from "react";
import { Link as RouterLink } from "react-router-dom";
const queryString = require('query-string');

const data = {
  'grant_type': 'client_credentials',
  'client_id': '5925d6eb-06a4-4199-9321-1ce5eb702a0b',
  'client_secret': 'S~K8Q~Gyunp0jSB6um9FAGabbMv-_orPGM_gzbnU',
  'resource': '8c3c6f36-9497-4e1e-bad2-7adace7c339e'
};

const TOKEN_URL='https://login.microsoftonline.com/chevron.onmicrosoft.com/oauth2/token';
const URL='https://pswsdfc.tengizchevroil.com/api/Psws/GetPeopleFullTextSearch?searchValue=muhammad';
let  USER_TOKEN:any;
const headers = new Headers();
    headers.append('content-type', 'application/x-www-form-urlencoded');
    headers.append('Cookie', 'buid=0.AQ4AoZ15_cG_NEKpHHKzocueJjZvPIyXlB5OutJ62s58M54OAAA.AQABAAEAAAD--DLA3VO7QrddgJg7WevrXDcITT-RDRlQHkFCxGA4ZhrUBd42KW9XEdiYpvwGNOAuG3XB1vxwS21anAGRp9Y1bSYinp5VWbXDBRTch4Km9MpSJvDau5L52JA8gdH5DCQgAA; fpc=AuUqIDFnh0tCn67AcrLwm46DieRHAQAAAKAdsdoOAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd');
    
    const urlencoded = new URLSearchParams();
    urlencoded.append("grant_type", "authorization_code");
    urlencoded.append("client_id", "5925d6eb-06a4-4199-9321-1ce5eb702a0b");
    urlencoded.append("client_secret", "S~K8Q~Gyunp0jSB6um9FAGabbMv-_orPGM_gzbnU");
    urlencoded.append("resource", "8c3c6f36-9497-4e1e-bad2-7adace7c339e");
    
  const config = {
  method: 'POST',
  headers: headers,
  data: '',
  url:TOKEN_URL,
};



export function Home() {
  
  useEffect(() => {

        const headers1 = { 
          'content-type': 'application/x-www-form-urlencoded',
          "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET, POST, PATCH, PUT, DELETE, OPTIONS",
                    "Access-Control-Allow-Headers": "Origin, Content-Type, X-Auth-Token, Authorization, Accept,charset,boundary,Content-Length",
                    "Origin": "http://localhost:3000/"
        };
        
const options = {
  method: 'POST',
  headers: headers,
  body: data
};
const FormData = require('form-data');
 
const form = new FormData();
form.append("grant_type", "client_credentials");
form.append("client_id", "5925d6eb-06a4-4199-9321-1ce5eb702a0b");
form.append("client_secret", "S~K8Q~Gyunp0jSB6um9FAGabbMv-_orPGM_gzbnU");
form.append("resource", "8c3c6f36-9497-4e1e-bad2-7adace7c339e");


axios.post(TOKEN_URL, form, { headers: headers1 })
        //axios.post(TOKEN_URL,options)
            .then(response => {
      console.log(response.data);
      USER_TOKEN = response.data.access_token;
      console.log('userresponse ' + response.data.access_token); 
    })   
    .catch((error) => {
      console.log('error ' + error);   
    });
    // axios(config)   
    // .then(response => {
    //   console.log(response.data);
    //   USER_TOKEN = response.data.access_token;
    //   console.log('userresponse ' + response.data.access_token); 
    // })   
    // .catch((error) => {
    //   console.log('error ' + error);   
    // });
    
    
    
    // const AuthStr = 'Bearer '.concat(USER_TOKEN); 
    // axios.get(URL, { headers: { Authorization: AuthStr,'Access-Control-Allow-Origin': '*' } })
    // .then(response => {
    //  // If request is good...
    //  console.log(response.data);
    // })
    // .catch((error) => {
    //  console.log('error ' + error);
    // });
  }, []);
  return (
      <>
          <AuthenticatedTemplate>
            {/* <ButtonGroup orientation="vertical">
              <Button component={RouterLink} to="/profile" variant="contained" color="primary">Request Profile Information</Button>
            </ButtonGroup> */}
            <TextField id="outlined-basic" label="Search" variant="outlined"  style = {{width : 500 }}/>
            <Button component={RouterLink} to="/profile" variant="contained" color="primary" style = {{marginLeft : 10 }}>Search</Button>
          </AuthenticatedTemplate>

          <UnauthenticatedTemplate>
            <Typography variant="h6" align="center">Please sign-in to see your profile information.</Typography>
          </UnauthenticatedTemplate>
      </>
  );
}
